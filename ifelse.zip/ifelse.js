const men = ['Washington', 'Lincoln', 'Trump', 'Socrates']
const areMenMortal = true

if(areMenMortal === true) {
    console.log('Socrates is mortal')
}


